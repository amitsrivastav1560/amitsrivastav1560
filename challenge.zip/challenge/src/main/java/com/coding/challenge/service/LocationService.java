package com.coding.challenge.service;

import com.coding.challenge.model.LocationDTO;

public interface LocationService {
    String setLocation(LocationDTO locationDTO);

    String updateLocation(LocationDTO locationDTO, int id);
}
