package com.coding.challenge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransactionSummaryResponse {
    private double sum;
    private double average;

    private double max;

    private double min;

    private double count;
}
