package com.coding.challenge.service;

import com.coding.challenge.model.TransactionDTO;
import com.coding.challenge.model.TransactionResponse;
import com.coding.challenge.model.TransactionSummaryResponse;

public interface TransactionService {
    TransactionResponse createTransaction(TransactionDTO transactionDTO);

    TransactionSummaryResponse summary();

    void deleteAll();
}
