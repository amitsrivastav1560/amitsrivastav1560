package com.coding.challenge.service.impl;

import com.coding.challenge.entity.LocationData;
import com.coding.challenge.exception.GlobalException;
import com.coding.challenge.model.LocationDTO;
import com.coding.challenge.repository.LocationRepository;
import com.coding.challenge.service.LocationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LocationServiceImpl implements LocationService {

    private final LocationRepository locationRepository;
    @Override
    public String setLocation(LocationDTO locationDTO) {
        LocationData locationData= new LocationData();
        locationData.setCity(locationDTO.getCity());
        locationData.setSetByAPI(true);
        locationRepository.save(locationData);
        return "Saved Successfully";
    }

    @Override
    public String updateLocation(LocationDTO locationDTO, int id) {
        LocationData locationData = locationRepository.findById(id)
                .orElseThrow(
                        ()-> {
                            throw new GlobalException(404, "User Not Found");
                        }
                );
        locationData.setCity(locationDTO.getCity());
        locationRepository.save(locationData);
        return "Updated the location details successfully";
    }
}
