package com.coding.challenge.controller;

import com.coding.challenge.model.TransactionDTO;
import com.coding.challenge.model.TransactionResponse;
import com.coding.challenge.model.TransactionSummaryResponse;
import com.coding.challenge.repository.TransactionRepository;
import com.coding.challenge.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
public class TransactionController {
    private final TransactionService transactionService;

    @PostMapping("/transactions")
    public ResponseEntity<String> createTransaction(@RequestBody TransactionDTO transactionDTO) {
        TransactionResponse transactionResponse = transactionService.createTransaction(transactionDTO);
        int code = transactionResponse.getCode();
        String response = transactionResponse.getResponse();

        return ResponseEntity.status(code).body(response);
    }

    @GetMapping("/statistics")
    public ResponseEntity<TransactionSummaryResponse> getSummary() {

        return ResponseEntity.ok(transactionService.summary());
    }

    @DeleteMapping("/transactions")
    public ResponseEntity<String> deleteAllTransactions() {
        transactionService.deleteAll();
        return ResponseEntity.status(204).body("Deleted Successfully");
    }
}
