package com.coding.challenge.service.impl;

import com.coding.challenge.entity.TransactionData;
import com.coding.challenge.exception.GlobalException;
import com.coding.challenge.model.TransactionDTO;
import com.coding.challenge.model.TransactionResponse;
import com.coding.challenge.model.TransactionSummaryResponse;
import com.coding.challenge.repository.TransactionRepository;
import com.coding.challenge.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {
    private final TransactionRepository transactionRepository;

    @Override
    public TransactionResponse createTransaction(TransactionDTO transactionDTO) {
        TransactionData transactionData = new TransactionData();
        transactionData.setAmount(transactionDTO.getAmount());

        LocalDateTime curr = LocalDateTime.parse(LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        LocalDateTime reqDateTime = transactionDTO.getTimestamp();
        if(reqDateTime.isAfter(curr))
            throw new GlobalException(422, "Transaction timestamp is in future");

        transactionData.setTimestamp(reqDateTime);
        transactionRepository.save(transactionData);

        TransactionResponse transactionResponse = new TransactionResponse();
        if (reqDateTime.plusSeconds(60).isBefore(curr)) {
            transactionResponse.setCode(204);
            transactionResponse.setResponse("Saved The Transaction Successfully But transaction Older than 60 sec");
        } else {
            transactionResponse.setCode(201);
            transactionResponse.setResponse("Saved The Transaction Successfully");
        }

        return transactionResponse;
    }

    @Override
    public TransactionSummaryResponse summary() {
        LocalDateTime curr = LocalDateTime.parse(LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        List<TransactionData> dataList = transactionRepository.findByTimestampAfter(curr.minusSeconds(60));
        if(dataList.isEmpty())
            throw new GlobalException(500, "No records exists in the database for last 60 seconds");

        double sum = 0, maxAmount = 0, minAmount = 0, average = 0, count = 0;


        for (TransactionData data : dataList){
            sum += data.getAmount();
            if(maxAmount == 0)
                maxAmount = data.getAmount();
            else
                maxAmount = Math.max(maxAmount, data.getAmount());


            if(minAmount == 0)
                minAmount = data.getAmount();
            else
                minAmount = Math.min(minAmount, data.getAmount());
        }

        TransactionSummaryResponse transactionSummaryResponse = new TransactionSummaryResponse();
        count = dataList.size();
        average = sum / count;

        transactionSummaryResponse.setCount(count);
        transactionSummaryResponse.setAverage(average);
        transactionSummaryResponse.setMax(maxAmount);
        transactionSummaryResponse.setMin(minAmount);
        transactionSummaryResponse.setSum(sum);

        return transactionSummaryResponse;
    }

    @Override
    public void deleteAll() {
        transactionRepository.deleteAll();
    }
}
