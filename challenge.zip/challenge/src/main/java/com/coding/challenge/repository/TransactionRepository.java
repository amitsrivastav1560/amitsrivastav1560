package com.coding.challenge.repository;

import com.coding.challenge.entity.TransactionData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<TransactionData, Integer> {
    List<TransactionData> findByTimestampAfter(LocalDateTime minusDays);
}
