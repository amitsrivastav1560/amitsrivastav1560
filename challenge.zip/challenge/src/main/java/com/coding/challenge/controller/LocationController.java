package com.coding.challenge.controller;

import com.coding.challenge.model.LocationDTO;
import com.coding.challenge.service.LocationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class LocationController {

    private final LocationService locationService;
    @PostMapping("/location")
    public ResponseEntity<String> addLocation(@RequestBody LocationDTO locationDTO) {
        return ResponseEntity.status(201).body(locationService.setLocation(locationDTO));
    }

    @PutMapping("/location/{id}")
    public ResponseEntity<String> addLocation(@RequestBody LocationDTO locationDTO, @PathVariable(value = "id") int id) {
        return ResponseEntity.status(201).body(locationService.updateLocation(locationDTO, id));
    }
}
